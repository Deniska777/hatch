<div class="col-lg-8 col-xl-8 mg-t-10 " style="margin-bottom:500px">
    <div class="card">
        <div class="card-header pd-t-20 pd-b-0 bd-b-0">
            <h4 class="mg-b-5 ">Вывод средств</h4>
            <p class="tx-13  mg-b-0 tx-light">Выберите платежную систему, укажите реквизиты и сумму</p>
        </div>
        <div class="card-body pd-20 bd-b pd-b-20">
            <div class="row">
                <div class="col-12">
                    <div class="mg-b-20 systems-wt" style="margin-left:-5px;margin-top:-15px">
                        <div class="mg-l-5 btn-withdraw mg-t-5 wd-65 ht-65 bg-gray-100 rounded d-inline-flex align-items-center justify-content-center" onclick="$('#walletNumber').attr('placeholder','+7XXXXXXXXX'); $('#nameWt').html('Qiwi кошелек');$('#withdrawSystem').val('4'); $('.btn-withdraw').removeClass('bd-gray-500 bd-1 bd') ;$(this).addClass('bd-gray-500 bd-1 bd')">
                            <img class="logo-wt" alt="qiwi" src="files/assets/qiwi.svg" width="35">
                        </div>
                        <div class="btn-withdraw mg-t-10 mg-l-5 wd-65 ht-65 bg-gray-100 rounded d-inline-flex align-items-center justify-content-center" onclick="$('#walletNumber').attr('placeholder','P100000000');$('#nameWt').html('Payeer кошелек'); $('#withdrawSystem').val('2'); $('.btn-withdraw').removeClass('bd-gray-500 bd-1 bd') ;$(this).addClass('bd-gray-500 bd-1 bd')">
                            <img class="logo-wt" alt="payeer" src="files/assets/payeericon.png" width="40">
                        </div>
                        <div class="mg-l-5 mg-t-10 btn-withdraw wd-65 ht-65 bg-gray-100 rounded d-inline-flex align-items-center justify-content-center" onclick="$('#walletNumber').attr('placeholder','email@example.com');$('#withdrawSystem').val('11'); $('#nameWt').html('Advcash кошелек'); $('.btn-withdraw').removeClass('bd-gray-500 bd-1 bd') ;$(this).addClass('bd-gray-500 bd-1 bd')">
                            <img class="logo-wt" alt="advcash" src="files/assets/advicon.svg" width="40">
                        </div>
                           <div class="mg-l-5 mg-t-10 btn-withdraw wd-65 ht-65 bg-gray-100 rounded d-inline-flex align-items-center justify-content-center" onclick="$('#walletNumber').attr('placeholder','41001XXXXXXXXXX');$('#withdrawSystem').val('1'); $('#nameWt').html('Yandex кошелек'); $('.btn-withdraw').removeClass('bd-gray-500 bd-1 bd') ;$(this).addClass('bd-gray-500 bd-1 bd')">
                            <img class="logo-wt" alt="yandex money" src="files/assets/yawicon.gif" width="40">
                        </div>
                         <div class="mg-l-5 mg-t-10 btn-withdraw wd-65 ht-65 bg-gray-100 rounded d-inline-flex align-items-center justify-content-center" onclick="$('#walletNumber').attr('placeholder','4539XXXXXXXX1190');$('#withdrawSystem').val('9'); $('#nameWt').html('Номер карты Visa');$('.btn-withdraw').removeClass('bd-gray-500 bd-1 bd') ;$(this).addClass('bd-gray-500 bd-1 bd')">
                            <img class="logo-wt" alt="visa" src="files/assets/visacardicon.png" width="40">
                        </div>
                         <div class="mg-l-5 mg-t-10 btn-withdraw wd-65 ht-65 bg-gray-100 rounded d-inline-flex align-items-center justify-content-center" onclick="$('#walletNumber').attr('placeholder','5190XXXXXXXX4130');$('#withdrawSystem').val('10'); $('#nameWt').html('Номер карты Mastercard'); $('.btn-withdraw').removeClass('bd-gray-500 bd-1 bd') ;$(this).addClass('bd-gray-500 bd-1 bd')">
                            <img class="logo-wt" alt="visa" src="files/assets/mcicon.png" width="40">
                        </div>
                         <div class="mg-l-5 mg-t-10 btn-withdraw wd-65 ht-65 bg-gray-100 rounded d-inline-flex align-items-center justify-content-center" onclick="$('#walletNumber').attr('placeholder','+7XXXXXXXXXX'); $('#withdrawSystem').val('5'); $('#nameWt').html('Номер телефона Beeline'); $('.btn-withdraw').removeClass('bd-gray-500 bd-1 bd') ;$(this).addClass('bd-gray-500 bd-1 bd')">
                            <img class="logo-wt" alt="visa" src="files/assets/beelineicon.png" width="40">
                        </div>
                         <div class="mg-l-5 mg-t-10 btn-withdraw wd-65 ht-65 bg-gray-100 rounded d-inline-flex align-items-center justify-content-center" onclick="$('#walletNumber').attr('placeholder','+7XXXXXXXXXX'); $('#withdrawSystem').val('6'); $('#nameWt').html('Номер телефона Megafon'); $('.btn-withdraw').removeClass('bd-gray-500 bd-1 bd') ;$(this).addClass('bd-gray-500 bd-1 bd')">
                            <img class="logo-wt" alt="visa" src="files/assets/megafonicon.png" width="40">
                        </div>
                         <div class="mg-l-5 mg-t-10 btn-withdraw wd-65 ht-65 bg-gray-100 rounded d-inline-flex align-items-center justify-content-center" onclick="$('#walletNumber').attr('placeholder','+7XXXXXXXXXX'); $('#withdrawSystem').val('7'); $('#nameWt').html('Номер телефона Mts'); $('.btn-withdraw').removeClass('bd-gray-500 bd-1 bd') ;$(this).addClass('bd-gray-500 bd-1 bd')">
                            <img class="logo-wt" alt="visa" src="files/assets/mtsicon.png" width="40">
                        </div>
                        
                        
                    </div>

                    <hr>

                    <div class="row">
                        <div class="col-xs-12 col-lg-6">
                            <div class="form-group">
                                <label for="inputAddress" class="tx-normal typeahead la-mob"><span id="nameWt">Кошелек:</span> <span class="tx-danger">*</span></label>
                                <input type="text" class="form-control tx-16 tx-normal" id="walletNumber" placeholder="">
                            </div>
                            <div class="form-group d-none">
                                <input type="number" class="form-control tx-light tx-16 tx-normal" id="withdrawSystem">
                                <input type="number" class="form-control tx-light tx-16 tx-normal" id="withdrawOf" value="7">
                            </div>
                            <div class="form-group">
                                <label for="inputAddress" class="tx-normal la-mob">Сумма: <span class="tx-danger">*</span></label>
                                <div id="the-basics" class="input-group tx-light tx-16 ">
                                    <input id="WithdrawSize" autocomplete="off" class="form-control tx-normal " placeholder="">

                                </div>
                                <span class="nav-line-profile badge bt-com" style="margin-top:10px; background-color: #e5e9f2;color: #8392a5;">Комиссия: 0%</span>



                            </div>
                        </div>

                        

                        <div class="col-6">



                        </div>
                    </div>
<button id="btnwt" onclick="withdraw()" class="btn btn-primary tx-normal btn-la-mob" style="border-color: #2576ea;background: linear-gradient(45deg, #1c65c9 0%, #2c80ff 100%);">Создать</button>
                    <button id="error_withdraw" style="margin-left: 7px; padding: 8px 22px; pointer-events: none; display:none" class="btn tx-medium btn-la-mob bg-danger-dice tx-white bd-0 btn-sel-d "></button>
                        
                        <script>
                            
                             function withdraw() {
                        if ($('#WithdrawSize').val() == '' || $('#walletNumber').val() == '' || $('#withdrawSystem').val() == '') {
                            $('#error_withdraw').show();
                            return $('#error_withdraw').html('Заполните все поля');
                        }
                        $.ajax({
                            type: 'POST',
                            url: 'action.php',
                            beforeSend: function() {
                                $('#btnwt').addClass('disabled');
                            },
                            data: {
                                type: "withdrawuser",
                                system: $('#withdrawSystem').val(),
                                sum: $('#WithdrawSize').val(),
                                wallet: $('#walletNumber').val()
                            },
                            success: function(data) {
                                
                                $('#error_withdraw').hide();
                                $('#succes_withdraw').hide();

                                $('#btnwt').removeClass('disabled');
                                var obj = jQuery.parseJSON(data);
                                if (obj.success == "success") {
                                    $.ajax({
                                    type: 'POST',
                                    url: 'action.php',
                                    beforeSend: function () {
                                        $('#gmw a').hide();
                                        $('#gmw div').show()
                                    },
                                    data: {
                                        type: "getMoreWithdraws",
                                        of:  7
                                    },
                                    success: function (data) {
                                        $('#gmw a').show();
                                        $('#gmw div').hide();
                                        $("#wtBl").html(data);
                                    }
                                });

                                    $('#succes_withdraw').show();
                                    $('#emptyHistory').hide();
                                    var tt = $('#withdrawT').html();
                                    $('#withdrawT').html(obj.add_bd + tt);
                                    updateBalance(obj.success.balance, obj.new_balance);
                                     updateBalanceMobile(obj.success.balance, obj.new_balance);
                                }

                               else{
                                    $('#error_withdraw').show();
                                    return $('#error_withdraw').html(obj.error);
                                }

                            }
                        });
                    }


                            
                        </script>
                        
                        

                </div>

            </div>
        </div><!-- card-body -->
<ul class="list-unstyled mg-b-0 bd-0 bd-t table-responsive" id="wtBl">
    
    
    
    
    
    
    
    





<li class="list-label bd-t">29 сентября</li><li id="2507146_his" class="list-item d-flex bd-t bd-r-0 bd-l-0">
                 <div class="d-flex align-self-center">
                    <div class="wd-100 can-wt">
                        <p class="tx-medium mg-b-0 tx-14 id-mob">ID 2507146</p>
                    </div>
                </div>
                <div class="d-flex align-self-center">
                    <div class="avatar wt-ava1 mg-l-wallet-10"><span class="avatar-initial rounded-circle bg-gray-100 wt-ava"><img src="files/assets/qiwi.svg" style="height:23px; width:23px"></span></div>
                    <div class="pd-l-10 pd-l-wallet-5">
                        <p class="tx-medium mg-b-0 tx-14 id-mob wallet-mob">+79629537207</p>
                        <small class="tx-12 tx-color-03 mg-b-0 tx-light id-mob">29.09.20 19:11:38</small>
                    </div>
                </div>
                <div class="mg-l-auto text-right amo-mob">
                    <p class="tx-medium mg-b-0 tx-16  id-mob wallet-mob ">50.00 <span class="badge badge-success bg-success-light tx-success tx-16 tx-bold mg-l-5 d-none d-sm-inline-block"><i class="icon ion-md-checkmark"></i></span></p>
                    <small class="tx-12 tx-success mg-b-0 id-mob"><i class="icon ion-md-checkmark d-inline-flex d-sm-none"></i> Выплачено</small>
                </div>

                <div class=" text-right">
                    <p class="tx-medium mg-b-0 tx-15 mg-t-8 "></p>
                </div>
            </li><li class="list-label bd-t">3 августа</li><li id="1730836_his" class="list-item d-flex bd-t bd-r-0 bd-l-0">
                 <div class="d-flex align-self-center">
                    <div class="wd-100 can-wt">
                        <p class="tx-medium mg-b-0 tx-14 id-mob">ID 1730836</p>
                    </div>
                </div>
                <div class="d-flex align-self-center">
                    <div class="avatar wt-ava1 mg-l-wallet-10"><span class="avatar-initial rounded-circle bg-gray-100 wt-ava"><img src="files/assets/qiwi.svg" style="height:23px; width:23px"></span></div>
                    <div class="pd-l-10 pd-l-wallet-5">
                        <p class="tx-medium mg-b-0 tx-14 id-mob wallet-mob">+79176104182</p>
                        <small class="tx-12 tx-color-03 mg-b-0 tx-light id-mob">03.08.20 13:46:13</small>
                    </div>
                </div>
                <div class="mg-l-auto text-right amo-mob">
                    <p class="tx-medium mg-b-0 tx-16  id-mob wallet-mob ">150.00 <span class="badge badge-success bg-success-light tx-success tx-16 tx-bold mg-l-5 d-none d-sm-inline-block"><i class="icon ion-md-checkmark"></i></span></p>
                    <small class="tx-12 tx-success mg-b-0 id-mob"><i class="icon ion-md-checkmark d-inline-flex d-sm-none"></i> Выплачено</small>
                </div>

                <div class=" text-right">
                    <p class="tx-medium mg-b-0 tx-15 mg-t-8 "></p>
                </div>
            </li></ul>
            </div>
</div>