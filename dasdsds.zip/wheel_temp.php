
<div class="col-lg-10 col-xl-10 mg-t-10">
    <div class="card">
        <div class="card-header pd-y-20 d-md-flex align-items-center justify-content-between d-none d-sm-block">
            <h4 class="mg-b-0">Wheel</h4>

        </div>
         <style>
                            
.wheel-circle{
	position: relavite;
    top: 5px;
    left: 5px;
    text-align: center;
    width: 350px;
	height: 375px;
	border-radius: 100%;
	margin-top: -50px;
	margin: 0 auto;
}
.active-border{
		transition:3s;
		margin:0 auto;
		box-shadow: 0px 0px 9px rgba(149,147,147,1);
    position: relative;
    text-align: center;
    width: 390px;
    height: 390px;
    border-radius: 100%;
    background-color:rgba(40,167,69,1);
    background-image:
        linear-gradient(91deg, transparent 50%, rgba(220,53,69,1) 50%),
        linear-gradient(90deg,  50%, transparent 50%);

}
.arrow-chance {
	text-align: center;
}
.arrow-chance i{
	margin-top: 17px;
	font-size: 20px;
	transform: rotate(-45deg);
	color:rgba(0,0,0,0.7);
}





.percent-chance-game
{
	width:20%;
	margin-top: 10px;
	height: 30px;
}
/*Target*/
.shadownone{
	box-shadow:none;
}
.target-2{
	margin-top:-365px;
}
.active-border-2{
	width:340px;
	height:340px;
}
.wheel-circle-2
{
	width:330px;
	height:330px;
}
.target-3{
	margin-top:-315px;
}
.active-border-3{
	width:290px;
	height:290px;
}
.wheel-circle-3
{
	width:280px;
	height:280px;
}
.target-4{
	margin-top:-265px;
}
.active-border-4{
	width:240px;
	height:240px;
}
.wheel-circle-4
{
	width:230px;
	height:230px;
}
#chanceArrowTarget{
	margin-top:90px;
}
.prec-target
{
	top:93;
	position: relative;
	font-size: 30px;
}
/*Tower*/
@media screen and (max-width: 1200px) {
.chat-main{
	height: 299px;
}
.left-side
{
	width: 55%;
}
.right-side
{
	width: 43%;
}
.start-game-btn{
	height: 40px;
}
.finish-game-btn{
	height: 40px;
}
.amout-bomb-btns
{
	flex-wrap: wrap;
}
.amout-bet-btn
{
	width: 18%;
}
.amout-bet-btn:nth-child(7)
{
	display: none;
}
.amout-bet-btn:nth-child(8)
{
	display: none;
}
.amout-bet-btn:nth-child(6)
{
	display: none;
}
.history-game
{
	display: none;
}
.finish-game
{
	width: 100%;
	flex-wrap: wrap;
}
.finish-game-btn
{
	width: 100%;
}
.circle{
	margin-bottom: 10px;
}
.start-game-btn{
	width: 100%
}

.box{
	margin-bottom: 11px;
}

.info-game-boxes{
	width: 100%;
	margin-top: 10px;
}

/*chance game*/
.wheel-circle
{
	width:320px;
	height: 320px;
}
.active-border
{
	width:330px;
	height: 330px;
}
.prec{
	top:140;
}
.chance-game-box-percent
{
	flex-wrap: wrap;
}

.set-chance-game-btn{
	width:45%;
	height: 40px;
	margin-top: 7.5px;
}
#startChanceGameBtn
{
	margin-left: -25%;
	width: 130%;
	margin-top: 10px;
}
#startTargetGameBtn
{
	margin-left: -25%;
	width: 130%;
	margin-top: 10px;
}
.target-2{
	margin-top:-305px;
}
.active-border-2{
	width:280px;
	height:280px;
}
.wheel-circle-2
{
	width:270px;
	height:270px;
}
.target-3{
	margin-top:-255px;
}
.active-border-3{
	width:230px;
	height:230px;
}
.wheel-circle-3
{
	width:220px;
	height:220px;
}
.target-4{
	margin-top:-205px;
}
.active-border-4{
	width:180px;
	height:180px;
}
.wheel-circle-4
{
	width:170px;
	height:170px;
}
#chanceArrowTarget{
	margin-top:90px;
}
.prec-target
{
	top:65;
}
}
@media screen and (max-width: 974px) {
.dice-all-content{
	width: 300px;
}
.dice-content
{
	font-size: 30px;
	width: 300px;
}
.dice-content-bottom{
	width: 300px;
}
.dice-content-bottom-item{
	width: 140px;
}
.chat{
	width: 210px;
}
.chat-main{
	height: 267px;
}
.chat-box{
	width: 210px;
}
.start-game-btn{
	height: 40px;
}
.finish-game-btn{
	height: 40px;
}
.main-contentos
{
	display: flex;
	flex-direction: row;
}
.left-side
{
	width: 56%;
}
.right-side
{
	width: 43%;
}
.number{
	font-size: 20px;
}

.title{
	margin-bottom:0px;
}
.box{
	margin-bottom: 5px;
}


.notif{
	right: 20px;
}

.table-bets{
	margin-top:15px;

}

#bg2{
		background: url('../img/bg2.png') no-repeat 50% 0;
}
/*chance game*/
.chance-game-box-percent{
	display: flex;
	flex-wrap: wrap;
}
.wheel-circle
{
	width:275px;
	height: 275px;
}
.active-border
{
	margin:0 auto;
	width:285px;
	height: 285px;
}
.prec{
	top:115;
}
.set-chance-game-btn{
	width:45%;
	height: 40px;
	margin-top: 7.5px;
}
.target-2{
	margin-top:-260px;
}
.active-border-2{
	width:235px;
	height:235px;
}
.wheel-circle-2
{
	width:225px;
	height:225px;
}
.target-3{
	margin-top:-210px;
}
.active-border-3{
	width:185px;
	height:185px;
}
.wheel-circle-3
{
	width:175px;
	height:175px;
}
.target-4{
	margin-top:-160px;
}
.active-border-4{
	width:135px;
	height:135px;
}
.wheel-circle-4
{
	width:125px;
	height:125px;
}
#chanceArrowTarget{
	margin-top:90px;
}
.prec-target
{
	top:40;
}
}
@media screen and (max-width: 840px) {
.tr1{
	display:none;
}
.tb2 i{
	font-size:50px;
}
.dice-all-content{
	width: 360px;
}
.dice-content
{
	font-size: 50px;
	width: 360px;
}
.dice-content-bottom{
	width: 360px;
}
.dice-content-bottom-item{
	width: 160px;
}
.chat-up{
	display: none;
}
.chat-mess{
	width: 90%;
}
.chachat{
	display: inline-block;
}
.container{
	width: 540px;
}

.start-game-btn{
	width: 40%;
	height: 50px;
}
.finish-game-btn{
	width: 40%;
	height: 50px;

}
.info-game-boxes{
 width: 55%;
 margin-top: 0px;
}

.chat{
	display: none;
}
.amout-bet-btn
{
	width:13%;
}
.amout-bet-btn:nth-child(7){
	display: inline-block;
}
.amout-bet-btn:nth-child(6){
	display: inline-block;
}
.main-contentos{
	flex-wrap: wrap;
}
.left-side{
	width: 100%;
	margin:0 auto;
}
.right-side
{
	width: 100%;
		margin:0 auto;
}
.mine{
	width:75px;
	height: 75px;
}

.box{
	margin-bottom: 10px;
}
.history-game{
	display: none;
}
.game-arrow{
	display: none;
}
.all-game
{
	margin-left: 0px;
	position: fixed;
	bottom: 0;
	left: 0;
	width: 100%;
	background: rgba(255,255,255,1);
}
.game-box
{
	margin-bottom: 0px;
	background: none;
}
.all-game-box
{
	display: flex;
	flex-direction: row;
	justify-content:space-around;
}
/* Chance game */
.chance-game-wheel{
	margin-bottom: 10px;
}

.wheel-circle
{
	width:380px;
	height: 380px;
}
.active-border
{
	width:390px;
	height: 390px;
}
.prec{
	top:170;
}
.target-2{
	margin-top:-365px;
}
.active-border-2{
	width:340px;
	height:340px;
}
.wheel-circle-2
{
	width:330px;
	height:330px;
}
.target-3{
	margin-top:-315px;
}
.active-border-3{
	width:290px;
	height:290px;
}
.wheel-circle-3
{
	width:280px;
	height:280px;
}
.target-4{
	margin-top:-265px;
}
.active-border-4{
	width:240px;
	height:240px;
}
.wheel-circle-4
{
	width:230px;
	height:230px;
}
#chanceArrowTarget{
	margin-top:90px;
}
.prec-target
{
	top:93;
}
}
@media screen and (max-width: 557px) {
.dice-all-content{
	width: 330px;
}
.dice-content
{
	font-size: 50px;
	width: 330px;
}
.dice-content-bottom{
	width: 330px;
}
.dice-content-bottom-item{
	width: 150px;
}
.chat-mess{
	width: 90%;
	margin-left: 5%;
}
.container{
	width: 360px;
}
.info-game-boxes{
 width: 100%;
 margin-top: 10px;
}
.minefield{
	width:325px;
	height: 325px;
}
.mine{
	width: 55px;
	height: 55px;
	line-height: 50px;
	font-size: 12px;

}
.minefield .fa-bomb{
	font-size: 25px;
}
.amount-bomb{
	width: 100%;
}
.circle{
	width: 49px;
	height: 49px;
	border-radius: 50%;
	margin-right: 12%;
	margin-bottom: 20px;
}
.circle:nth-child(4){
	margin-right: 0%;
}
.history-content{
	width:190px;

}
.history
{
	margin-left: 25px;
}
.amout-bet-btn{
	width:33px;
	font-size: 13px;
	margin-right: 0px;

}
.start-game-btn{
	width: 100%;
	height: 40px;
}
.finish-game{
	width: 100%;
}
.finish-game-btn{
	width: 100%;
	height: 40px;
}
.table-bets{
	font-size: 14px;
}

.info-game{
	margin-left: 0px;
}
.info-game:last-child{
	margin-left: 75px;
}
.notification-box{
	width: 80%;
}
.amount-bet-content{
	margin-top: 5px;
}
.table-bets .fa-user-circle{
	display: none;
}
.ref-text-promo{
	font-size: 13px;
}
/* Chance game */
.wheel-circle
{
	width:330px;
	height: 330px;
}
.chance-game-wheel
{
	margin-left:-6px;
}
.active-border
{
	width:340px;
	height: 340px;
}
.prec{
	top:150;
}

#autoStartChanceGameBtn{
	width: 100%;
}
.set-chance-game-btn{
	width:111px;
	margin-bottom: 10px;
}
.set-chance-game-btn:nth-child(2){
	margin-right: 0px;
}
.vk-mess-box{
	display: none;
}
.target-2{
	margin-top:-315px;
}
.active-border-2{
	width:290px;
	height:290px;
}
.wheel-circle-2
{
	width:280px;
	height:280px;
}
.target-3{
	margin-top:-265px;
}
.active-border-3{
	width:240px;
	height:240px;
}
.wheel-circle-3
{
	width:230px;
	height:230px;
}
.target-4{
	margin-top:-215px;
}
.active-border-4{
	width:190px;
	height:190px;
}
.wheel-circle-4
{
	width:180px;
	height:180px;
}
#chanceArrowTarget{
	margin-top:90px;
}
.prec-target
{
	top:67;
}
}

@media(max-width: 840px){
	#chanceArrow{
		margin-top: 25px;
	}
	.wheel-circle {
		
			width: 300px;
			height: 300px;
		
	}
}

@media screen and (max-width: 600px) {
	
	.wheel-circle {
		
			width: 250px;
			height: 250px;
		
	}
	
	
}
.btn-wheel-black{
	background: #272d3c;
	border: 0;
}
.btn-wheel-red{
	background: #bf526f;
	border: 0;
}
.btn-wheel-blue{
	background: #345ed7;
	border: 0;
}
.btn-wheel-yellow{
	background: #eed152;
	border: 0;
}
.btn-wheel-black:hover{
	background: #2e3034 !important;
}
.btn-wheel-red:hover{
	background: #ca4165 !important;
}
.btn-wheel-blue:hover{
	background: #2b50bc !important;
}
.btn-wheel-yellow:hover{
	background: #e1c030 !important;
}
.btn-wheel-yellow:focus{
	box-shadow: 0 0 0 .2rem rgba(238, 209, 82, 0.53)
}
.btn-wheel-black:focus{
	box-shadow: 0 0 0 .2rem rgba(39, 45, 60, 0.5)
}
.btn-wheel-red:focus{
	box-shadow: 0 0 0 .2rem rgba(237, 50, 50, 0.48)
}
.btn-wheel-blue:focus{
	box-shadow: 0 0 0 .2rem rgba(52, 94, 215, 0.48)
}
.btn-wheel-black:disabled{
	background: #272d3cb5;
}
.btn-wheel-red:disabled{
	background: #E77C86;
}
.btn-wheel-blue:disabled{
	background: #7C96E4;
}
.btn-wheel-yellow:disabled{
	background: #F4E28F;
}

                        </style>
                        <script>
                        function update(balance) {
    			updateBalance(parseInt($("#userBalance").html()), balance);
                updateBalanceMobile(parseInt($("#userBalanceMobile").html()), balance);
}
                        	function wheel(colorWheel){
                        	    window.online = "2";
                        
    var animateInt = getRandomInt(7, 12);
    var animateRotateInt = getRandomInt(0, 4);
    $("#x50").css({"transform":"rotate(183deg)"});
    $("#x50").css({"transition":"0s"});
    $.ajax({
    type: 'POST',
    url: '../action.php',
beforeSend: function() {
   },
      data: {
  
     type: "wheel",
     color: colorWheel,
     size: $('#amountBetInputWheelGame').val()
     },
      success: function(response){
        obj = $.parseJSON(response);
        if(obj.success == "fatal"){
             window.online = "1";
                        
      //return false;
        }
       
        if(obj.success == "success"){
            var bal = obj.new;
            var dtype = obj.type;
            var dmess = obj.mess;
         setTimeout(function() {
             update(bal);
              window.online = "1";
                        
         }, animateInt*1000);
          var rotateWheel = (obj.key*(360/54) + 360*3-3+180+11+animateRotateInt)
          $("#x50").css({"transform":"rotate("+rotateWheel+"deg)","transition":""+animateInt+"s"});
          $(".dice-game-box-percent-btn").attr("disabled","disabled");
        
          setTimeout(function(){
              $(".dice-game-box-percent-btn").removeAttr("disabled","disabled");
         
            },animateInt*1000);

        }
      $('#hashBetWheel').html(obj.hash);
        if(obj.valuesWheel == 2){
          setTimeout( function(){
          $("#ar").css("color","rgb(39, 45, 60)");
          
        },animateInt*1000);
        }
        if(obj.valuesWheel == 3){
          setTimeout( function(){
          $("#ar").css("color","rgb(191, 82, 111)");
         
        },animateInt*1000);
        }
        if(obj.valuesWheel == 5){
          setTimeout( function(){
          $("#ar").css("color","rgb(52, 94, 215)");
          },animateInt*1000);
        }
        if(obj.valuesWheel == 50){
          setTimeout( function(){
          $("#ar").css("color","rgb(238, 209, 82)");
        
        },animateInt*1000);
        }
      }
    });
  };
function getRandomInt(min, max)
{
  return Math.floor(Math.random() * (max - min + 1)) + min;
}
                        </script>
        <div class="card-body " style="padding-bottom: 30px;">
            <div class="row ">
                <div class="col-xs-12 col-lg-6 mg-b-20">
                    <div class="pd-dc">
                        <div class="chance-game-wheel">
                                <div id="activeBorder" class="wheel-circle">
                                    <img id="x50" src="x50.svg" style="position: relative; margin-top: -50px;transform: rotate(183deg);">
                                    <div id="wheelCircle" class="wheel-circle">
                                    </div>
                                </div>
                                <center>
                                <div class="arrow-chance" style="margin-top: 5px;width:20px;height:20px;transform: rotate(315deg);"> <svg class="svg-inline--fa fa-location-arrow fa-w-16" id="ar" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="location-arrow" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" data-fa-i2svg=""><path fill="currentColor" d="M444.52 3.52L28.74 195.42c-47.97 22.39-31.98 92.75 19.19 92.75h175.91v175.91c0 51.17 70.36 67.17 92.75 19.19l191.9-415.78c15.99-38.39-25.59-79.97-63.97-63.97z"></path></svg><!-- <i class="fas fa-location-arrow" id="chanceArrow"></i> --> </div>
                            </center></div> 
                        </div>
                </div>
                <div class="col-lg-6 ">
                    <div class="col-lg-12 but-dice">
                        <h6 class="mg-b-15 h-mob-d">Cумма:</h6>
<div class="input-group tx-light tx-24 dice-input">
<input value="1" id="amountBetInputWheelGame" autocomplete="off" style="border-bottom-right-radius: 0;border-bottom-left-radius: 0;" onkeyup="validateDiceGameAmount(this);updateResultSize()" class="tx-20 tx-center form-control tx-normal tx-rubik" placeholder="Сумма">
</div>
<div style="margin-top: -1px; " class="btn-group tx-rubik d-flex justify-content-center">
<button onclick="$('#amountBetInputWheelGame').val($('#userBalance').attr('myBalance'));updateResultSize()" style="border-top-left-radius: 0; padding: 0;" class="tx-gray-600 btn btn-xs btn-white   tx-13 mb-mines">Max</button>
<button onclick="$('#amountBetInputWheelGame').val(1);updateResultSize()" style="border-top-right-radius: 0; padding: 0;" class="tx-gray-600 btn btn-xs btn-white   tx-13 mb-mines">Min</button>
<button onclick="var x = ($('#amountBetInputWheelGame').val()*2);$('#amountBetInputWheelGame').val(parseFloat(x.toFixed(2)));updateResultSize()" style="border-top-right-radius: 0; padding: 0;" class="tx-gray-600 btn btn-xs btn-white   tx-13 mb-mines">x2</button>
<button onclick="$('#amountBetInputWheelGame').val(Math.max(($('#amountBetInputWheelGame').val()/2).toFixed(2), 1));updateResultSize()" style="border-top-right-radius: 0; padding: 4px 0;" class="tx-gray-600 btn btn-xs btn-white   tx-13 mb-mines">/2</button>
</div>

<div class="row mt-3" >
<div class="form-group col-6 col-md-3">
<button onclick="wheel('2')" id="buttonMin" style="padding: 11px;" class="dice-game-box-percent-btn btn btn-dark btn-block tx-thin btn-la-mob btn-sel-d">x2</button>
</div>
<div class="form-group col-6 col-md-3 ">
<button onclick="wheel('3')" id="buttonMax" style="padding: 11px;" class="dice-game-box-percent-btn btn btn-danger btn-block tx-thin btn-la-mob btn-sel-d">x3</button>
</div>
<div class="form-group col-6 col-md-3 ">
<button onclick="wheel('5')" id="buttonMax" style="padding: 11px;" class="dice-game-box-percent-btn btn btn-info btn-block tx-thin btn-la-mob btn-sel-d">x5</button>
</div>
<div class="form-group col-6 col-md-3 ">
<button onclick="wheel('50')" id="buttonMax" style="padding: 11px;" class="dice-game-box-percent-btn btn btn-warning btn-block tx-thin btn-la-mob btn-sel-d">x50</button>
</div>
</div>
                    </div>
                    <?php if($sid) {  } else {?> <div class="col-md-12  tx-xs-center tx-color-03 tx-thin d-none d-sm-block hash-mob" id="">
                            Авторизуйтесь!                        </div> <?php } ?>
                    <div class="divider-text hash-mob mg-t-20">Hash игры</div><div class="col-md-12  tx-xs-center tx-color-03 tx-thin d-none d-sm-block hash-mob" id="<?php if($sid) {?>hashBetWheel <?php } else {?>noneere<?php } ?>">
                            64e5fc4c37f6f4832bb67c485197fc27f907925091fe9b06f8b02576fb6bc697b3d5f520f5054e0b6f30b6605b331fbb5bc466ac27a3e8417031a410ece6b22a                        </div>
                    <div class="form-group col-md-12 but-dice ht-30">
<center><div class="spinner-border" id="betLoad" role="status" style="color: #7a86a1;
    border: .1em solid currentColor;
    border-right-color: transparent;display:none">
                          <span class="sr-only">Loading...</span>
                        </div></center>
                        <button id="succes_bet" style="  padding: 11px;pointer-events: none;margin-top: 0px;display:none;" class="btn btn-block tx-medium btn-la-mob bg-success-dice tx-white bd-0 btn-sel-d "></button>
                        <button id="error_bet" style="padding: 11px; pointer-events:none; display:none; margin-top:0" class="btn btn-block tx-medium btn-la-mob bg-danger-dice tx-white bd-0 btn-sel-d "></button>
                        <span id="checkBet" class="align-items-center link-03 justify-content-center mg-t-5" href="#checkModal" data-toggle="modal" style="display:none; cursor:pointer">Проверить игру</span>
                 
                    </div>
                </div>
            </div><!-- card-body -->
        </div><!-- card-body -->
    </div><!-- card -->
<div class="card mg-b-10 mg-t-10 hash-mob">
    <div class="card-header pd-t-20 d-sm-flex align-items-start justify-content-between bd-b-0 pd-b-0">
        <div>
            <h6 class="mg-b-5">История</h6>
            <p class="tx-13 tx-color-03 mg-b-0"></p>
        </div>
        <div class="d-flex mg-t-20 mg-sm-t-0">
            <div class="btn-group flex-fill">
                  <button class="btn btn-white btn-xs bt-table active" onclick="$('.bt-table').removeClass('active'); $(this).addClass('active'); $('#myresponse').hide(); $('#response').show(); ">Все игры</button>
                <button class="btn btn-white btn-xs bt-table" onclick="$('.bt-table').removeClass('active'); $(this).addClass('active');  $('#response').hide(); $('#myresponse').show();">Мои игры</button>
            </div>
        </div>
    </div><!-- card-header -->

    <div class="table-responsive mg-t-20 mg-b-15">
        <table class="table table-dashboard mg-b-0 table-live">
            <thead>
                <tr>
                    
                    <th class="text-center wd-10p">Игра</th>
                    <th class="text-center wd-20p">Логин</th>
                    <th class="text-center wd-25p">Сумма</th>
                    <th class="text-center wd-20p">Коэффициент</th>
                    <th class="text-center wd-25p">Результат</th>
                </tr>
            </thead>
            <style>
                #response tr:hover{
                    cursor:pointer;
                }
            </style>
            <tbody id="response">

                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
               
                
            </tbody>
        
            <tbody id="myresponse" style="display:none;border-top: 0;">

                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
                <tr style="color: transparent !important;">
                    <td class="text-center"><svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-box" style="    margin-top: -4px;margin-right: 3px;"><path d="M12.89 1.45l8 4A2 2 0 0 1 22 7.24v9.53a2 2 0 0 1-1.11 1.79l-8 4a2 2 0 0 1-1.79 0l-8-4a2 2 0 0 1-1.1-1.8V7.24a2 2 0 0 1 1.11-1.79l8-4a2 2 0 0 1 1.78 0z"></path><polyline points="2.32 6.16 12 11 21.68 6.16"></polyline><line x1="12" y1="22.76" x2="12" y2="11"></line></svg></td>
                    <td class="text-center">Login123</td>
                    <td class="text-center">1,00</td>
                    <td class="text-center">1.22</td>
                    <td class="text-center tx-semibold">1,55</td>
                </tr>
               
                
            </tbody>
        
        </table>
    </div><!-- table-responsive -->
</div><!-- card -->

</div>