<?
$history = '
<div class="card mg-b-10 mg-t-10 hash-mob">
<div class="card-header pd-t-20 d-sm-flex align-items-start justify-content-between bd-b-0 pd-b-0">
<div>
<h6 class="mg-b-5">История</h6>
<p class="tx-13 tx-color-03 mg-b-0"></p>
</div>
<div class="d-flex mg-t-20 mg-sm-t-0">
<div class="btn-group flex-fill">
</div>
</div>
</div>
<div class="table-responsive mg-t-20 mg-b-15">
<table class="table table-dashboard mg-b-0 table-live">
<thead>
<tr>
<th class="text-center ">Логин</th>
<th class="text-center">Число</th>
<th class="text-center">Цель</th>
<th class="text-center ">Сумма</th>
<th class="text-center ">Шанс</th>
<th class="text-center ">Выигрыш</th>
</tr>
</thead>
<style>
#response td{
                   text-align:center;
                }
                #response tr:hover{
                    cursor:pointer;
                }
            </style>
<tbody id="response">
</tbody>
</table>
</div>
</div>
';

?>