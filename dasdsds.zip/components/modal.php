<div class="modal fade" id="modalSignIn" tabindex="-1" role="dialog" style="display: none;" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered wd-sm-400" role="document">
                        <div class="modal-content">
                            <div class="modal-body pd-20 pd-sm-40">
                                <a href="" role="button" class="close pos-absolute t-15 r-15" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </a>

                                <div>
                                    <h4>Авторизация</h4>
                                    <p class="tx-color-03 tx-thin"></p>
                                    <a href="https://oauth.vk.com/authorize?client_id=7688313&redirect_uri=https://<?=$_SERVER['SERVER_NAME']?>/auth.php&response_type=code" class="btn btn-outline-facebook btn-block mg-b-15"><i class="fa fa-vk"></i> Войти через Вконтакте</a>
                                    <div class="form-group">
                                        <label>Логин</label>
                                        <input id="userLogin" class="form-control" placeholder="">
                                    </div>
                                    <div class="form-group">
                                        <div class="d-flex justify-content-between mg-b-5">
                                            <label class="mg-b-0-f">Пароль</label>
                                        </div>
                                        <input id="userPass" type="password" class="form-control" placeholder="">
                                    </div>
                                                                        <div id="error_enter" class="alert alert-danger tx-center tx-red" role="alert" style="color: rgb(219, 52, 69);padding: 9px;display:none"></div>
                                    <button id="butEnter" class="btn btn-primary btn-block" onclick="login()">Войти</button>
                                    <div class="tx-13 mg-t-20 tx-center">Нет аккаунта? <a data-dismiss="modal" aria-label="Close" href="#modalSignUp" data-toggle="modal">Создать аккаунт</a></div>
                                
                               
                                
                                </div>
                            </div><!-- modal-body -->
                        </div><!-- modal-content -->
                    </div><!-- modal-dialog -->
                </div>

                <div class="modal fade" id="modalSignUp" tabindex="-1" role="dialog" style="display: none;" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered wd-sm-400" role="document">
                        <div class="modal-content">
                            <div class="modal-body pd-20 pd-sm-40">
                                <a href="" role="button" class="close pos-absolute t-15 r-15" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </a>

                                <div>
                                    <h4>Создание аккаунта</h4>
                                    <div class="form-group">
                                        <label>Логин</label>
                                        <input id="userRegsiter" type="text" class="form-control" placeholder="">
                                    </div>
                                    <div class="form-group">
                                        <label>Пароль</label>
                                        <input id="userPassRegister" type="password" class="form-control" placeholder="">
                                    </div>
                                    <div class="form-group">
                                        <label>Повторите пароль</label>
                                        <input id="userPassRegister1" type="password" class="form-control" placeholder="">
                                    </div>
                                    <div class="form-group">
                                        Создавая аккаунт, вы соглашаетесь с <a href="terms" target="_blanc">пользовательским соглашением</a> и <a href="policy" target="_blanc">политикой конфеденциальности</a>.
                                    </div>
                                    <div id="error_register" class="alert alert-danger tx-center tx-red" role="alert" style="color: rgb(219, 52, 69);padding: 9px;display:none"></div>
                                    <button id="butRegister" onclick="register()" class="btn btn-primary btn-block">Создать аккаунт</button>
                                    <div class="tx-13 mg-t-20 tx-center">Есть аккаунт? <a data-dismiss="modal" aria-label="Close" href="#modalSignIn" data-toggle="modal">Войти</a></div>
                                </div>
                            </div><!-- modal-body -->
                        </div><!-- modal-content -->
                    </div><!-- modal-dialog -->
                </div>

                




            </div><!-- row -->

        </div><!-- container -->

    </div><!-- content -->
 <script>
                                    
                                    function login() {
                                if ($('#userLogin').val().length < 4) {
                                    $('#error_enter').css('display', 'block');
                                    return $('#error_enter').html('Логин от 4 символов');
                                }
                                if ($('#userPass').val() == '') {
                                    $('#error_enter').css('display', 'block');
                                    return $('#error_enter').html('Введите пароль');
                                }

                                
                                
                                
                                $.ajax({
                                    type: 'POST',
                                    url: '/action.php',
                                    beforeSend: function() {
                                        
                                        $('#butEnter').html('<div class="spinner-border spinner-border-sm tx-white link-03 tx-medium tx-spacing--0 tx-10"></div>');
                                        $('#butEnter').addClass('disabled');
                                        $('#error_enter').hide();
                                        
                                    },
                                    data: {
                                        type: "login",
                                        login: $("#userLogin").val(),
        								pass: $("#userPass").val()  
                                    },
                                    success: function(data) {
                                        
                                

                                        var obj = jQuery.parseJSON(data);
                                        if (obj.success == "success") {
                                            window.location.href = '';
                                            // return false;
                                        }else{
                                            $('#butEnter').html('Войти');
                                        $('#butEnter').removeClass('disabled');
                                           
                                       
                                        $('#error_enter').html(obj.error);
                                        $('#error_enter').css('display', 'block');
                                        }


                                    }
                                });
                            }
                            
                            function register() {
                                if ($('#userRegsiter').val().length < 4) {
                                    $('#error_register').css('display', 'block');
                                    return $('#error_register').html('Логин от 4 символов');
                                }
                                if ($('#userPassRegister').val() == '') {
                                    $('#error_register').css('display', 'block');
                                    return $('#error_register').html('Введите пароль');
                                }
                                if ($('#userPassRegister1').val() !== $('#userPassRegister').val()) {
                                    $('#error_register').css('display', 'block');
                                    return $('#error_register').html('Пароли не совпадают');
                                }
                            

                               
   
                                $.ajax({
                                    type: 'POST',
                                    url: '/action.php',
                                    beforeSend: function() {
                                        $('#butRegister').html('<div class="spinner-border spinner-border-sm tx-white link-03 tx-medium tx-spacing--0 tx-10"></div>').addClass('disabled');
                                        $('#error_register').hide();
                                    },
                                    data: {
                                        type: "registration",
                                         login: $("#userRegsiter").val(),
        								pass: $("#userPassRegister").val(),  
        								repeatpass: $("#userPassRegister1").val()   
                                    },
                                    success: function(data) {
                                        $('#butRegister').html('Зарегистрироваться').removeClass('disabled');
                                        $('#error_register').hide();
                                        var obj = jQuery.parseJSON(data);
                                            if (obj.success == "success") {
                                             window.location.href = '';
                                            // return false;
                                        }else{
                                          
                                       
                                        $('#error_register').html(obj.error);
                                        $('#error_register').show();
                                        }


                                    }
                                });
                            }
                        
                                    
                                    
                                    
                                </script>
                                



    







    <script type="text/javascript" src="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script src="/files/js.js"></script>
    <script src="/files/dfg_002.js"></script>

    <div class="modal fade" id="firstBonus" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered wd-sm-400" role="document">
            <div class="modal-content">
                <div class="modal-body pd-20 pd-sm-40">
                    <a href="" role="button" class="close pos-absolute t-15 r-15" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </a>

                    <div id="wizard1" role="application" class="wizard clearfix">
                        
                                                                        <div class="steps clearfix align-items-center justify-content-center">
                            <ul role="tablist">
                                <li role="tab" class="<? if($bonus==1){ echo'';}else{echo'first current';}?>" aria-disabled="false" aria-selected="true"><a id="wizard1-t-0" href="#wizard1-h-0" aria-controls="wizard1-p-0"><span class="current-info audible">current step: </span><span class="number ">1</span></a></li>
                                <li role="tab" class="<? if($bonus==1){ echo'first current';}else{echo'disabled';}?>" aria-disabled="true"><a id="wizard1-t-1" href="#wizard1-h-1" aria-controls="wizard1-p-1"><span class="number">2</span></a></li>
                            </ul>
                        </div>
                        <div class="content clearfix" style="min-height:0!important">
                        	
                            <h3 id="wizard1-h-0" tabindex="-1" class="title current tx-center ">
                            	<? if ($bonus == 0){?>
                            	Привяжите аккаунт Вконтакте
                            	<?}else if($bonus == 1){?>
                            	Получите бонус
                            	<?}?>
                            	</h3>
                                                    </div>
                        <div class="actions ">
                        	<? if ($bonus == 0){?>
                            	<a href="https://oauth.vk.com/authorize?client_id=7688313&redirect_uri=https://<?=$_SERVER['SERVER_NAME']?>/vk_bonus.php&response_type=code" class="tx-center "><i class="fa fa-vk"></i> Привязать</a>
                     
                            	<?}else if($bonus == 1){?>
                            <a onclick="getBonus()" class="tx-center " href='#'>Получить</a>
                     
                            	<?}?>
                               </div>
                                            </div>
                                        <center id="xrqexr" style="font-size:11px;margin-top: 15px;opacity:0.5;cursor:pointer;" onclick="hideBonus()">Больше не показывать предложение</center>
                                    </div><!-- modal-body -->
            </div><!-- modal-content -->
        </div><!-- modal-dialog -->
    </div>
    
    <script>
        
        function getBonus() {

                $.ajax({
                                            type: 'POST',
                                            url: '/action.php',
                                             beforeSend: function(data) {
                                                        $('#bonBut').addClass('disabled');
                                                    },
                                            data: {
                                                type: 'getBonus'
                                            },
                                            success: function(data) {
                                                $('#error_bonuss1').hide();
                                                $('#bonBut').removeClass('disabled');
                                             var obj = jQuery.parseJSON(data);
                                                if (obj.success == "success") {
                                                    $('#firstBonus').modal('toggle');
                                                    $(".absh").hide();
                                                        $('#userBalanceMobile').html(obj.new_balance);
                                                         $('#userBalance').html(obj.new_balance);
                                                
                                                    return;
                                                   
                                                } 
                                                else {
                                                    $('#error_bonuss1').show();
                                                    return $('#error_bonuss1').html(obj.error.text);
                                                }
                                            }
                                        });
               
                    
            }
            
            function hideBonus() {
                        $.ajax({
                            type: 'POST',
                            url: '/action.php',
                            data: {
                                type: "hideBonus",
                            },
                            success: function(data) {
                                var obj = jQuery.parseJSON(data);
                                if (obj.success == "success") {
                                    $('#firstBonus').modal('toggle');
                                }
                            }
                        });
                    }
            
        
        
    </script>

    <div class="modal fade" id="userSettings" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered " role="document">
            <div class="modal-content">
                <div class="modal-body pd-x-25 pd-sm-x-30 pd-t-40 pd-sm-t-20 pd-b-15 pd-sm-b-20">
                    <a href="" role="button" class="close pos-absolute t-15 r-15" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </a>

                    <div class="nav-wrapper mg-b-20 tx-13">
                        <div>
                            <nav class="nav nav-line tx-medium">
                                <a href="#performance" class="nav-link active" data-toggle="tab">Настройки</a>

                            </nav>
                        </div>
                    </div><!-- nav-wrapper -->

                    <div class="tab-content">
                         
                        <div id="performance" class="tab-pane fade active show">
                            <h6>Темная тема</h6>
                            <div class="row row-xs mg-t-15">
                                <div class="col-lg-4">
                                    <div class="d-md-flex">
                                        <div id="fnWrapper" class="parsley-input">
                                            <div class="custom-control custom-switch">
                                                <input autocomplete="off" type="checkbox" class="custom-control-input" id="customSwitch1" onchange="Cookies.set('tm','1');location.reload(); "><label class="custom-control-label" for="customSwitch1" style="color:transparent">A</label>                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> <hr>
                            <h6>Смена пароля</h6>
                            <div class="row row-xs mg-t-15">
                                <div class="col-lg-4">
                                    <div class="d-md-flex ">
                                        <div id="fnWrapper" class="parsley-input">
                                            <input type="password" id="resetPass" name="firstname" class="form-control " placeholder="Старый пароль" autocomplete="off" data-parsley-class-handler="#fnWrapper" required="">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <div class="d-md-flex ">
                                        <div id="lnWrapper" class="parsley-input ">
                                            <input type="password" id="resetPassRepeat" name="lastname" class="form-control " placeholder="Новый пароль" autocomplete="off" data-parsley-class-handler="#lnWrapper" required="">
                                        </div><!-- form-group -->
                                    </div>
                                </div>
                                <div class="col-lg-4">
                                    <button onclick="resetPass()" class="btn btn-block btn-primary tx-normal rpbss">Сохранить</button>
                                </div>
                                <span id="error_resetPass" class="tx-danger mg-t-15" style="display:none">Пароль</span>
                                <span id="succes_resetPass" class="tx-success mg-t-15" style="display:none">Пароль изменен</span>
                                
                                <script>

                                        function resetPass() {
										if ($('#resetPass').val() == ''){
										$('#error_resetPass').show();
										return $('#error_resetPass').html('Введите пароль');
										}
										if ($('#resetPass').val().length < 5){
										$('#error_resetPass').show();
										return $('#error_resetPass').html('Пароль от 5 символов');
										}
									if ($('#resetPass').val() != $('#resetPassRepeat').val()){
										$('#error_resetPass').show();
										return $('#error_resetPass').html('Пароли не совпадают');
									}
									$.ajax({
                                        type: 'POST',
                                        url: 'action.php',
										beforeSend: function() {
										    $('.rpbss').addClass("disabled");
											$('#error_resetPass').hide();
											$('#succes_resetPass').hide();
										},	
                                        data: {
                                            type: "resetPassPanel",
                                            sid: Cookies.get('sid'),
                                            newPass: $('#resetPass').val()
                                        },
                                        success: function(data) {
                                            $('.rpbss').removeClass("disabled");
                                            var obj = jQuery.parseJSON(data);
                                            if ('success' in obj) {
                                               $("#succes_resetPass").show();
											  Cookies.set('sid', obj.success.sid, { path: '/',secure:true });
																						 return false;
                                            }else{
												$('#error_resetPass').show();
												return $('#error_resetPass').html(obj.error.text);
											}
                                        }
                                    });
                                    
                                }
								</script>
                            </div>
                            <hr>
                            <h6 class="d-none">Аккаунт Вконтакте</h6>
                            <div class="row row-xs mg-t-15 d-none">
                                <div class="col-lg-4">
                                    <div class="d-md-flex">
                                        <div id="fnWrapper" class="parsley-input">
                                            <a href="" target="_blank">https://werwr.wrer</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <hr>
                           
                           
                            
                            <div class="row row-xs mg-t-15">
                                <div class="col-lg-12">
                                    <div class="d-md-flex">
                                            <button type="submit" class="btn btn-outline-primary btn-block tx-normal" onclick="location.href = 'logout';">Выйти из аккаунта</button>
                                    </div>
                                </div>
                            </div>
                        </div><!-- tab-content -->
                    </div>
                </div><!-- modal-content -->
            </div><!-- modal-dialog -->
        </div>
    </div>
    
    
    <div class="modal fade" id="checkModal" tabindex="-1" role="dialog" style="display: none;" aria-hidden="true" onclick="22">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                            <div class="modal-body pd-x-25 pd-sm-x-30 pd-t-40 pd-sm-t-20 pd-b-15 pd-sm-b-20">
                                            <div class="text-center">
                                              <div class="spinner-border"></div>
                                            </div>

                                            </div><!-- modal-body -->
                                        </div><!-- modal-content -->
                                    </div><!-- modal-dialog -->
                                    <script>
                                    
                                    $("#checkModal").on('hide.bs.modal', function(){
    history.pushState(null, null, '/');
  });
  
                                    </script>
                                </div>
                            


    <div class="modal fade" id="depositModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel4" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content tx-14">
                <div class="modal-header">
                    <h4 class="mg-b-5 ">Пополнение баланса</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="form-group mg-b-5">
                        <label class="tx-normal la-mob">Выберите платежную систему:</label>
                    </div>
                    <div class="d-none d-sm-flex flex-row justify-content-start">
                       
                       
                        <div class="wd-150 ht-65 bg-gray-100 mg-l-5 btn-deposit d-inline-flex align-items-center justify-content-center" onclick="$('#depositSystem').val('4'); $('.btn-deposit').removeClass('bd-gray-500 bd-1 bd') ;$(this).addClass('bd-gray-500 bd-1 bd')">
                            <img src="https://nvuti.la/assets/fk-logo.png" style="width:100px">
                        </div>
                        
                    </div>


                    <div class="d-sm-none d-block ">

                        <div class="row row-xs">

                                                       <div class="col-6">
                                <div class="wd-150 ht-65 bg-gray-100 btn-deposit d-inline-flex align-items-center justify-content-center" onclick="$('#depositSystem').val('4'); $('.btn-deposit').removeClass('bd-gray-500 bd-1 bd') ;$(this).addClass('bd-gray-500 bd-1 bd')" style="height: 55px!important;width: 100%!important;">
                                    <div class="wd-150 ht-65 bg-gray-100 mg-l-5 btn-deposit d-inline-flex align-items-center justify-content-center" onclick="$('#depositSystem').val('4'); $('.btn-deposit').removeClass('bd-gray-500 bd-1 bd') ;$(this).addClass('bd-gray-500 bd-1 bd')">
                            <img src="https://nvuti.la/assets/fk-logo.png" style="width:45px">
                        </div>
                                    </div>

                            </div>

                            

                        </div>

                        <div class="row-md">






                        </div>
                    </div>

                    <div class="form-group mg-t-15">
                        <label class="tx-normal la-mob">Сумма:</label>
                        <div id="the-basics" class="input-group tx-light tx-16 col-6 pd-0">
                            <input id="depositSize" autocomplete="off" class="form-control tx-normal " style="border-top-right-radius: 5px;border-bottom-right-radius: 5px; " value="100">
                            <input id="depositSystem" autocomplete="off" class="form-control tx-normal d-none" placeholder="">
                        </div>
                        <span class="nav-line-profile badge bt-com" style="margin-top:10px; background-color: #e5e9f2;color: #8392a5;">Комиссия: 0%</span>

                    </div>
                    <button id="depositButton" onclick="deposit()" class="btn btn-primary tx-normal btn-la-mob" style="padding: 8px 18px;">Далее</button>
                    <button id="error_deposit" style="margin-left: 7px; padding: 8px 22px; pointer-events: none; display:none" class="btn tx-medium btn-la-mob bg-danger-dice tx-white bd-0 btn-sel-d "></button>
                    <script>
                        function deposit() {
						if ( $('#depositSystem').val() > 6 || !$.isNumeric($('#depositSystem').val())){
							$('#error_deposit').show();
							return $('#error_deposit').html('Укажите систему пополнения');
						}
						if ( $('#depositSize').val() == ''){
							$('#error_deposit').show();
							return $('#error_deposit').html('Введите сумму');
						}
						
						if (!$.isNumeric($('#depositSize').val())){
							$('#error_deposit').show();
							return $('#error_deposit').html('Введите корректную сумму');
						}
						$.ajax({
                    type: 'POST',
                    url: 'action.php',
                    data: {
                        type: "deposit",
                        
                        system: $('#depositSystem').val(),
                        size: $('#depositSize').val()
                    },
					  beforeSend: function(data) {
						
						$('#depositButton').addClass('disabled');
					},
                    success: function(data) {
                        var obj = jQuery.parseJSON(data);
                       if (obj.success == "success") {
                       	// alert(obj.locations)
						window.location.href = obj.locations;
                        }

                        else{
                            $('#depositButton').removeClass('disabled');
                            $('#error_deposit').show();
                            return $('#error_deposit').html(obj.error);
                        }

                    }
                });
						
					}
                        
                        
                        
                    </script>
                    
                    
                    
                    <div class="table-responsive mg-t-30 ">
                        <div class="table-responsive">
                            <table class="table table-sm mg-b-0 table-deposit">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Дата</th>
                                        <th scope="col">Сумма</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    
                                    	<? $deposits = mysql_query("SELECT * FROM kot_payments WHERE user_id='$id'");
		while ($row = mysql_fetch_array($deposits)){
			$summa = $row['suma'];
			$i = $row['id'];
			$data = $row['data'];
			
			echo '<tr><td>'.$i.'</td><td>'.$data.'</td><td>'.$summa.'</td></tr>' ;
			
			
		}
	?>


                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<script>
    $('#checkModal').on('show.bs.modal', function (e) {
        var gi = $(e.relatedTarget).attr('gameid');
        
        if (isNaN(window.location.pathname.split("/")[2]) && window.location.pathname.split("/")[1] !== 'game'){
        $.ajax({
        type: 'POST',
        url: '/action.php',
        data: {
            type: "gameHistory",
            id: gi
        },
        success: function (data) {
            history.pushState(null, null, '/game/' + gi);
            $("#checkModal .modal-body").html(data);
        }
    });
        
        
        
        $(this).find('#modalGameId').html(gi);
        }
    });





        $('[data-toggle="tooltip"]').tooltip();

      

        $(".js-range-slider").ionRangeSlider({

            skin: "round",
            min: 2,
            max: 24,
            from: 3,
            grid: true,


        });
        route();
        
        

    </script>
