<?
$mainpanel = '<div class="row row-xs mg-b-25">
<div class="col-12">
<div class="alert alert-primary alert-dismissible fade show tx-13 absh" role="alert" style="border-radius: 5px;">
Создателем этого скрипта является группа  <a href="https://vk.com/public190356777" class="">GameScripts</a>
<button type="button" class="close" data-dismiss="alert" aria-label="Close">
<span aria-hidden="true">×</span>
</button>
</div>
</div>
<div class="col-6 col-lg-3">
<div class="card card-profile">

<img src="/1.jpeg" class="card-img-top" alt="" style="height:135px">
<div class="card-body tx-13">
<div>
<h4 class="mg-t-45">Dice</h4>
<a href="dice" class="btn btn-block btn-white bt-mob">Играть</a>
</div>
</div>
</div>
</div>
<div class="col-6 col-lg-3 ">
<div class="card card-profile">
<img src="/2.jpeg" class="card-img-top " alt="" style="height:135px">
<div class="card-body tx-13">
<div>
<h4 class="mg-t-45">Mines</h4>
<a href="/mine" class="btn btn-block btn-white  bt-mob">Играть</a>
</div>
</div>
</div>
</div>
<div class="col-6 col-lg-3 mg-t-sm-10">
<div class="card card-profile">
<img src="/4.jpeg" class="card-img-top " alt="" style="height:135px">
<div class="card-body tx-13">
<div>
<h4 class="mg-t-45">Coin</h4>
<a href="/coin" class="btn btn-block btn-white  bt-mob">Играть</a>
</div>
</div>
</div>
</div>
<div class="col-6 col-lg-3 mg-t-sm-10">
<div class="card card-profile">
<img src="/3.jpeg" class="card-img-top " alt="" style="height:135px">
<div class="card-body tx-13 ">
<div>
<h4 class="mg-t-45">Wheel</h4>
<a href="/wheel" class="btn btn-block btn-white bt-mob">Играть</a>
</div>
</div>
</div>
</div>

</div>
';
?>